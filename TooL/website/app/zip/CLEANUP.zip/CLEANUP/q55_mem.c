#include<stdio.h>
int main()
{
    int n,m[1000],t1[1000],t2[1000],t,tt,f,k;
    scanf("%d",&t);
    for(tt=1;tt<=t;tt++)
    {scanf("%d",&n);
    scanf("%d",&k);
    for(f=1;f<=k;f++)
    scanf("%d",&m[f]);
    int i,l,k1,k2,c,j;
    i=1,l=0,k1=0,k2=0,c;
        while(i<=n)
                   {while(i<=n) 
                   {
                                c=0;
                     for(j=1;j<=k;j++)
                     {
                     if(i==m[j])
                     {
                     i++;
                     c++;
                     break;}
                     }
                     if(c==0)
                     break;
        }             
        if(i<=n)
        {
                if(l%2==0)
                {t1[k1]=i;
                k1++;
                i++;
                l++;
                }
                else
                {t2[k2]=i;
                k2++;i++;l++;
                }
        }         
        }
        for(i=0;i<k1;i++)
        printf("%d\t",t1[i]);
        printf("\n");    
        for(i=0;i<k2;i++)
        printf("%d\t",t2[i]);
        printf("\n");
        }
        return 0;}
        
           
                   