#include<stdio.h>
int main()
{
	int a,num;
	scanf("%d",&a);
	while(a--)
	{
	scanf("%d",&num);
	num=num/2 *2;
	printf("%d\n",num);
	}
return 0;
}