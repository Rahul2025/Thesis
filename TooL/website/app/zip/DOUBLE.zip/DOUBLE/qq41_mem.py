n = input()
while n > 0 :
	n = n -1
	x = input()
	if (x % 2):
		print x - 1
	else:
		print x