import sys
sys.stdin.readline()
for line in sys.stdin:
    print int(line)/2*2