import urllib.request
print(urllib.request.urlopen("http://facebook.com").read())