from urllib.request import urlopen
print(urlopen('https://sourceforge.net/').read())