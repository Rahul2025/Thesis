#include<iostream>
using namespace std;
int main()
{
    long t,n;
    cin>>t;
    while(t--)
    {
              cin>>n;
              if((n-1)%4==0)
              cout<<"ALICE"<<endl;
              else
              cout<<"BOB"<<endl;
              }
              return 0;
              }