t = input()
while t>0:
	a = raw_input()
	a = a.split()
	counts = {'2':0, '3':0, '4':0, '5':0, '6':0, '7':0, '8':0, '9':0, 'T':0, 'J':0, 'Q':0, 'K':0, 'A':0, 'H':0, 'S':0, 'C':0, 'D':0}
	ranks = ['A', '2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
	str_seq = "A23456789TJQKA"
	seq = ""
	for x in a:
		counts[x[0]] = counts[x[0]] + 1
		counts[x[1]] = counts[x[1]] + 1

	maxR='2'

	secR='2'

	for o in ranks:
		c=counts[o]
		while c>0:
			seq = seq + o
			c = c-1

	for x in a:
		if counts[x[0]]>counts[maxR]:
			maxR=x[0]

	for x in a:
		if x[0]!=maxR and counts[x[0]]>counts[secR]:
			secR=x[0]

	
	allsame=False
	if counts['H']==5 or counts['S']==5 or counts['D']==5 or counts['C']==5:
		allsame=True

	straight=False
	if len(seq) == 5 and str_seq.find(seq)!=-1:
		straight = True
		
	elif len(seq) == 6 and (str_seq.find(seq[0:-1])!=-1 or str_seq.find(seq[1:])!=-1):
		straight=True

	if allsame and (counts['A']==1 and counts['K']==1 and counts['Q']==1 and counts['J']==1 and counts['T']==1):
		print "royal flush"
	elif allsame and straight:
		print "straight flush"
	elif counts[maxR]==4:
		print "four of a kind"
	elif counts[maxR]==3 and counts[secR]==2:
		print "full house"
	elif allsame:
		print "flush"
	elif straight:
		print "straight"
	elif counts[maxR]==3:
		print "three of a kind"
	elif counts[maxR]==2 and counts[secR]==2:
		print "two pairs"
	elif counts[maxR]==2:
		print "pair"
	else:
		print "high card"
	t = t - 1