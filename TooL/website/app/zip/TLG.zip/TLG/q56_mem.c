#include<stdio.h>
int main()
{
int a,b,player,lead1=0,lead2=0,gr=0,t,i,lead,pl;
scanf("%d",&t);
for(i=1;i<=t;i++)
{
scanf("%d %d",&a,&b);
lead1=lead1+a;
lead2=lead2+b;
if(lead1>lead2)
{
lead=lead1-lead2;
pl=1;
}
else
{
lead=lead2-lead1;
pl=2;
}
if(lead>gr)
{
if(pl==1)
{
gr=lead;
player=1;
}
else
{
gr=lead;
player=2;
}
}
}
printf("%d %d",player,gr);
return 0;
}