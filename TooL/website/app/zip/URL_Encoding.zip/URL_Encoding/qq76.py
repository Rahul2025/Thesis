import urllib
s = 'http://foo/bar/'
s = urllib.quote(s)